from __future__ import annotations

import json
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


class OllamaError(RuntimeError):
    """Raised when Ollama cannot generate a response."""


class OllamaClient:
    def __init__(self, base_url: str, model: str, request_timeout: int = 300) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.request_timeout = request_timeout

    def generate(self, prompt: str) -> str:
        payload = json.dumps(
            {
                "model": self.model,
                "prompt": prompt,
                "stream": False,
                "options": {"temperature": 0.2},
            }
        ).encode("utf-8")
        request = Request(
            f"{self.base_url}/api/generate",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urlopen(request, timeout=self.request_timeout) as response:
                body = json.loads(response.read().decode("utf-8"))
        except HTTPError as error:
            detail = error.read().decode("utf-8", errors="replace").strip()
            raise OllamaError(f"Ollama returned HTTP {error.code}: {detail}") from error
        except (URLError, TimeoutError, UnicodeDecodeError, json.JSONDecodeError) as error:
            raise OllamaError(
                f"Could not get a valid response from Ollama at "
                f"{self.base_url}: {error}"
            ) from error

        if not isinstance(body, dict):
            raise OllamaError("Ollama returned an invalid response payload.")
        generated = body.get("response")
        if not isinstance(generated, str) or not generated.strip():
            raise OllamaError("Ollama returned an empty or invalid response.")
        return generated
