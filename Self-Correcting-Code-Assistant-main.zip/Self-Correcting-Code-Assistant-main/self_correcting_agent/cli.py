from __future__ import annotations

import argparse
import sys
from pathlib import Path

from self_correcting_agent.agent import SelfCorrectingAgent
from self_correcting_agent.executor import run_code
from self_correcting_agent.ollama import OllamaClient, OllamaError


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="self-correcting-agent",
        description="Generate Python with Ollama, review it, and iteratively run fixes.",
    )
    parser.add_argument("task", help="Describe the Python program to create.")
    parser.add_argument("--model", default="deepseek-coder:6.7b")
    parser.add_argument("--ollama-url", default="http://localhost:11434")
    parser.add_argument("--output", type=Path, default=Path("generated_code.py"))
    parser.add_argument("--max-attempts", type=int, default=5)
    parser.add_argument("--timeout", type=int, default=10, help="Seconds per run.")
    parser.add_argument(
        "--request-timeout", type=int, default=300, help="Seconds to wait for Ollama."
    )
    return parser


def _approve(code: str, attempt: int) -> bool:
    print(f"\n--- Generated code (attempt {attempt}) ---\n{code}")
    try:
        answer = input(
            "Review this code. Run it on this machine? [y/N]: "
        ).strip().lower()
    except (EOFError, KeyboardInterrupt):
        print("\nExecution cancelled.")
        return False
    return answer == "y"


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.max_attempts < 1 or args.timeout < 1 or args.request_timeout < 1:
        parser.error("attempt and timeout values must be positive integers.")

    if args.output.exists():
        try:
            overwrite = input(f"{args.output} exists. Overwrite it? [y/N]: ")
        except (EOFError, KeyboardInterrupt):
            print("\nCancelled.")
            return 2
        if overwrite.strip().lower() != "y":
            print("Cancelled; existing file was not changed.")
            return 2

    client = OllamaClient(args.ollama_url, args.model, args.request_timeout)
    agent = SelfCorrectingAgent(
        client, run_code, max_attempts=args.max_attempts, execution_timeout=args.timeout
    )
    try:
        result = agent.run(args.task, args.output, _approve)
    except (OllamaError, OSError, ValueError) as error:
        print(f"Error: {error}", file=sys.stderr)
        return 1

    if result.execution is None:
        print(f"Code saved to {args.output}; execution was not approved.")
        return 2
    if result.success:
        print(f"\nSuccess after {result.attempts} attempt(s). Code saved to {args.output}")
        if result.execution.stdout:
            print("\nProgram output:\n" + result.execution.stdout, end="")
        if result.execution.stderr:
            print("\nProgram stderr:\n" + result.execution.stderr, file=sys.stderr)
        return 0

    print(
        f"\nNo working result after {result.attempts} attempt(s). "
        f"Latest code saved to {args.output}."
    )
    if result.execution.stderr:
        print(result.execution.stderr, file=sys.stderr)
    if result.execution.stdout:
        print(result.execution.stdout)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
