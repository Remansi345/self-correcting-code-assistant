from self_correcting_agent.cli import main

raise SystemExit(main())
