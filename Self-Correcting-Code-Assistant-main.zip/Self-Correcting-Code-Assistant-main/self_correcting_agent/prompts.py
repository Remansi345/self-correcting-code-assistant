SYSTEM_PROMPT = """\
You are an expert Python engineer.
Write a complete, executable Python program for the user's task.
Return only Python code, without Markdown fences or explanations.
Do not claim that the program was run or tested.
"""


def build_initial_prompt(task: str) -> str:
    return f"{SYSTEM_PROMPT}\nTASK:\n{task}"


def build_repair_prompt(task: str, code: str, error: str) -> str:
    return (
        f"{SYSTEM_PROMPT}\n"
        "The previous program failed when it was executed. Correct the root cause "
        "and return the complete corrected program, not a diff.\n\n"
        f"ORIGINAL TASK:\n{task}\n\n"
        f"PREVIOUS CODE:\n{code}\n\n"
        f"EXECUTION RESULT:\n{error}\n"
    )
