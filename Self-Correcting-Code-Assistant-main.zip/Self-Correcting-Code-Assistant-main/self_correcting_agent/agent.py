from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Protocol

from self_correcting_agent.executor import ExecutionResult
from self_correcting_agent.prompts import build_initial_prompt, build_repair_prompt


class CodeGenerator(Protocol):
    def generate(self, prompt: str) -> str: ...


Executor = Callable[[str, int], ExecutionResult]
Approval = Callable[[str, int], bool]


@dataclass(frozen=True)
class AgentResult:
    success: bool
    attempts: int
    code: str
    execution: ExecutionResult | None


def extract_code(response: str) -> str:
    text = response.strip()
    fenced = re.fullmatch(
        r"```(?:python|py)?\s*\n?(.*?)\n?```", text, flags=re.IGNORECASE | re.DOTALL
    )
    if fenced:
        text = fenced.group(1).strip()
    if not text:
        raise ValueError("The model returned no Python code.")
    return text + "\n"


class SelfCorrectingAgent:
    def __init__(
        self,
        generator: CodeGenerator,
        executor: Executor,
        max_attempts: int = 5,
        execution_timeout: int = 10,
    ) -> None:
        if max_attempts < 1:
            raise ValueError("max_attempts must be at least 1.")
        if execution_timeout < 1:
            raise ValueError("execution_timeout must be at least 1.")
        self.generator = generator
        self.executor = executor
        self.max_attempts = max_attempts
        self.execution_timeout = execution_timeout

    def run(
        self,
        task: str,
        output_path: Path,
        approve: Approval,
    ) -> AgentResult:
        prompt = build_initial_prompt(task)
        last_code = ""

        for attempt in range(1, self.max_attempts + 1):
            last_code = extract_code(self.generator.generate(prompt))
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(last_code, encoding="utf-8")

            if not approve(last_code, attempt):
                return AgentResult(False, attempt, last_code, None)

            execution = self.executor(last_code, self.execution_timeout)
            if execution.success:
                return AgentResult(True, attempt, last_code, execution)

            prompt = build_repair_prompt(task, last_code, execution.feedback)

        return AgentResult(False, self.max_attempts, last_code, execution)
