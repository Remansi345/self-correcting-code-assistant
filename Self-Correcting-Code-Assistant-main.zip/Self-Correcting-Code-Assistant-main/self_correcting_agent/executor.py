from __future__ import annotations

import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class ExecutionResult:
    success: bool
    stdout: str
    stderr: str
    returncode: int | None

    @property
    def feedback(self) -> str:
        if self.success:
            return "Program exited successfully."
        if self.returncode is None:
            return self.stderr or "Program did not complete."
        return (
            f"Exit code: {self.returncode}\n"
            f"STDOUT:\n{self.stdout or '(empty)'}\n"
            f"STDERR:\n{self.stderr or '(empty)'}"
        )


def run_code(code: str, timeout_seconds: int = 10) -> ExecutionResult:
    with tempfile.TemporaryDirectory(prefix="self-correcting-agent-") as directory:
        script_path = Path(directory) / "generated_program.py"
        script_path.write_text(code, encoding="utf-8")
        try:
            completed = subprocess.run(
                [sys.executable, "-I", str(script_path)],
                cwd=directory,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=timeout_seconds,
                check=False,
            )
        except subprocess.TimeoutExpired as error:
            return ExecutionResult(
                success=False,
                stdout=_as_text(error.stdout),
                stderr=f"Execution timed out after {timeout_seconds} seconds.",
                returncode=None,
            )
        except OSError as error:
            return ExecutionResult(
                success=False,
                stdout="",
                stderr=f"Could not start generated code: {error}",
                returncode=None,
            )

    return ExecutionResult(
        success=completed.returncode == 0,
        stdout=completed.stdout,
        stderr=completed.stderr,
        returncode=completed.returncode,
    )


def _as_text(value: str | bytes | None) -> str:
    if value is None:
        return ""
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return value
