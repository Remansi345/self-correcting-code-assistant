"""A local-first, self-correcting Python code assistant."""

__version__ = "0.1.0"
