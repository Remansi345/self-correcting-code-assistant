<div align="center">

# Self-Correcting Code Assistant

**A local-first Python coding assistant that generates, runs, and improves code with Ollama.**

[![Python 3.10+](https://img.shields.io/badge/Python-3.10%2B-3776AB?logo=python&logoColor=white)](https://www.python.org/)
[![Powered by Ollama](https://img.shields.io/badge/LLM-Ollama-black?logo=ollama&logoColor=white)](https://ollama.com/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

</div>

Describe a program in plain language. The assistant asks a local Ollama model to write it, shows you the code, and waits for your approval before running it. If the program fails, the error is sent back to the model for a limited number of repair attempts.

> **You stay in control:** generated code is displayed and execution requires your approval on every attempt.

## Contents

- [See the workflow](#see-the-workflow)
- [Requirements](#requirements)
- [Get started](#get-started)
- [Try it](#try-it)
- [Command options](#command-options)
- [Safety](#safety)
- [Run the tests](#run-the-tests)
- [License](#license)

## See the workflow

```text
Your task → Ollama generates code → You review it → You approve execution
                                                        │
                                 ┌──────────────────────┴──────────────────────┐
                                 │                                             │
                              Success                                    Error captured
                                 │                                             │
                              Finished                      Ollama repairs code → Review again
```

<details>
<summary><strong>What happens when I run a task?</strong></summary>

1. The assistant sends your task to Ollama's local HTTP API.
2. The generated program is saved to `generated_code.py` (or your chosen output path) and displayed in the terminal.
3. You review the code and choose whether to run it.
4. If execution fails, the assistant gives the captured output and error to Ollama and requests a corrected program.
5. The review-and-approval step repeats until the program succeeds, you decline, or the attempt limit is reached.

</details>

## Requirements

- Python 3.10 or newer
- [Ollama](https://ollama.com/) installed and running
- A code-generation model available in Ollama

This project has no third-party Python runtime dependencies.

## Get started

<details open>
<summary><strong>Windows (PowerShell)</strong></summary>

From the project directory:

```powershell
ollama pull deepseek-coder:6.7b
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -e .
```

</details>

<details>
<summary><strong>macOS / Linux</strong></summary>

From the project directory:

```bash
ollama pull deepseek-coder:6.7b
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -e .
```

</details>

Start Ollama before using the assistant. The default model is `deepseek-coder:6.7b`; pull it once with `ollama pull deepseek-coder:6.7b`, or choose another installed model with `--model`.

## Try it

```console
$ self-correcting-agent "Write a Python program that prints the first 10 Fibonacci numbers"

--- Generated code (attempt 1) ---
print("...")

Review this code. Run it on this machine? [y/N]:
```

Type `y` only after reviewing the displayed code. Any other response leaves the code saved without executing it. If the command is not installed, use the module entry point:

```bash
python -m self_correcting_agent "Write a Python program that prints the first 10 Fibonacci numbers"
```

By default, the current draft is saved as `generated_code.py`. If that file already exists, the assistant asks before overwriting it.

<details>
<summary><strong>More example tasks</strong></summary>

```bash
python -m self_correcting_agent "Read a CSV file and print the average of its salary column"
python -m self_correcting_agent "Create a command-line unit converter for miles and kilometers"
python -m self_correcting_agent "Write a script that prints today's date"
```

</details>

## Command options

| Option | Default | Description |
| --- | --- | --- |
| `--model MODEL` | `deepseek-coder:6.7b` | Ollama model to use |
| `--ollama-url URL` | `http://localhost:11434` | Ollama server base URL |
| `--output PATH` | `generated_code.py` | File where the current draft is saved |
| `--max-attempts N` | `5` | Maximum number of generated versions |
| `--timeout SECONDS` | `10` | Maximum run time for each generated program |
| `--request-timeout SECONDS` | `300` | Maximum wait for each Ollama request |

For example, use a different model and save to a separate file:

```powershell
python -m self_correcting_agent "Create a script that prints today's date" --model qwen2.5-coder:7b --output .\date_script.py
```

Show all available options:

```bash
python -m self_correcting_agent --help
```

## Safety

Generated Python is arbitrary code. **Review every version before approving it.** The execution timeout and temporary working directory are convenience limits, **not a security sandbox**. Generated code can access files, processes, and services available to your user account. Do not approve code you do not trust.

For genuinely untrusted code, run it in a properly isolated container or virtual machine with restricted filesystem access, network access, and resource limits.

## Run the tests

Run the test suite using Python's built-in test runner:

```bash
python -m unittest discover -s tests -v
```

## License

Distributed under the [MIT License](LICENSE).
