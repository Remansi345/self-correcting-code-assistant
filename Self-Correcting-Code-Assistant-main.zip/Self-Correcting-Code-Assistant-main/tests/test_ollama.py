import json
from unittest.mock import Mock, patch
import unittest

from self_correcting_agent.ollama import OllamaClient, OllamaError


class FakeResponse:
    def __init__(self, payload: object) -> None:
        self.payload = payload

    def __enter__(self) -> "FakeResponse":
        return self

    def __exit__(self, *_args: object) -> None:
        return None

    def read(self) -> bytes:
        return json.dumps(self.payload).encode("utf-8")


class OllamaTests(unittest.TestCase):
    @patch("self_correcting_agent.ollama.urlopen")
    def test_sends_non_streaming_request_and_returns_code(self, urlopen: Mock) -> None:
        urlopen.return_value = FakeResponse({"response": "print('hello')"})
        client = OllamaClient("http://localhost:11434/", "test-model")

        result = client.generate("write hello")

        self.assertEqual(result, "print('hello')")
        request = urlopen.call_args.args[0]
        self.assertEqual(request.full_url, "http://localhost:11434/api/generate")
        self.assertFalse(json.loads(request.data)["stream"])

    @patch("self_correcting_agent.ollama.urlopen")
    def test_rejects_empty_response(self, urlopen: Mock) -> None:
        urlopen.return_value = FakeResponse({"response": ""})
        with self.assertRaises(OllamaError):
            OllamaClient("http://localhost:11434", "test-model").generate("task")

    @patch("self_correcting_agent.ollama.urlopen")
    def test_rejects_non_object_response(self, urlopen: Mock) -> None:
        urlopen.return_value = FakeResponse([])
        with self.assertRaises(OllamaError):
            OllamaClient("http://localhost:11434", "test-model").generate("task")


if __name__ == "__main__":
    unittest.main()
