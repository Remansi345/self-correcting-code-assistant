import unittest

from self_correcting_agent.executor import run_code


class ExecutorTests(unittest.TestCase):
    def test_successful_program_captures_stdout(self) -> None:
        result = run_code("print('hello')", timeout_seconds=3)
        self.assertTrue(result.success)
        self.assertEqual(result.stdout, "hello\n")

    def test_failed_program_captures_stderr(self) -> None:
        result = run_code("raise RuntimeError('broken')", timeout_seconds=3)
        self.assertFalse(result.success)
        self.assertIn("RuntimeError: broken", result.stderr)

    def test_timeout_is_reported(self) -> None:
        result = run_code("import time; time.sleep(10)", timeout_seconds=2)
        self.assertFalse(result.success)
        self.assertIn("timed out", result.stderr)


if __name__ == "__main__":
    unittest.main()
