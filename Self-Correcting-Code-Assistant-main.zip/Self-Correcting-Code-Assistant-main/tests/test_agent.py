from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from self_correcting_agent.agent import SelfCorrectingAgent, extract_code
from self_correcting_agent.executor import ExecutionResult


class FakeGenerator:
    def __init__(self, responses: list[str]) -> None:
        self.responses = iter(responses)
        self.prompts: list[str] = []

    def generate(self, prompt: str) -> str:
        self.prompts.append(prompt)
        return next(self.responses)


class AgentTests(unittest.TestCase):
    def test_extracts_python_fence(self) -> None:
        self.assertEqual(extract_code("```python\nprint('hello')\n```"), "print('hello')\n")

    def test_retries_with_execution_feedback_and_saves_working_code(self) -> None:
        generator = FakeGenerator(["print(undefined_name)", "print('fixed')"])
        executions = iter(
            [
                ExecutionResult(False, "", "NameError: undefined_name", 1),
                ExecutionResult(True, "fixed\n", "", 0),
            ]
        )
        with TemporaryDirectory() as directory:
            output = Path(directory) / "generated.py"
            result = SelfCorrectingAgent(
                generator, lambda _code, _timeout: next(executions), max_attempts=2
            ).run("Print fixed", output, lambda _code, _attempt: True)

            self.assertTrue(result.success)
            self.assertEqual(result.attempts, 2)
            self.assertIn("NameError: undefined_name", generator.prompts[1])
            self.assertEqual(output.read_text(encoding="utf-8"), "print('fixed')\n")

    def test_declined_execution_stops_before_running_code(self) -> None:
        generator = FakeGenerator(["print('not run')"])
        ran = False

        def executor(_code: str, _timeout: int) -> ExecutionResult:
            nonlocal ran
            ran = True
            return ExecutionResult(True, "", "", 0)

        with TemporaryDirectory() as directory:
            result = SelfCorrectingAgent(generator, executor).run(
                "Do nothing", Path(directory) / "draft.py", lambda _code, _attempt: False
            )

        self.assertFalse(result.success)
        self.assertIsNone(result.execution)
        self.assertFalse(ran)

    def test_requires_positive_attempt_count(self) -> None:
        with self.assertRaises(ValueError):
            SelfCorrectingAgent(FakeGenerator([]), lambda *_: ExecutionResult(True, "", "", 0), 0)


if __name__ == "__main__":
    unittest.main()
